# Video Speed Changer — Export Edition

This version adds a **Create & Download Video** button.

Features:
- Upload/drag-and-drop a local video.
- Change playback speed from 0.25x to 3x.
- Toggle original pitch preservation for playback.
- Export the modified video locally in the browser.
- Downloads a WebM file.

Open `index.html` in a recent Chrome or Edge browser.

Note: Browser-only video export has limitations. The included implementation uses MediaRecorder/WebCodecs-compatible browser APIs and exports WebM. For professional-grade MP4 export, exact audio time-stretch/pitch preservation, and broader browser compatibility, the next step would be a WebAssembly FFmpeg implementation.
